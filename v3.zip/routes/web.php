<?php

use App\Http\Controllers\AccountReportsController;
use App\Http\Controllers\Accounts;
use App\Http\Controllers\AdminDashboard;
use App\Http\Controllers\AverageCostingController;
use App\Http\Controllers\BalanceSheetController;
use App\Http\Controllers\BrandController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ChartOfAccountController;
use App\Http\Controllers\ContractSettingController;
use App\Http\Controllers\ContractVoucherController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\ExpenseController;
use App\Http\Controllers\FinishedGoodsStockController;
use App\Http\Controllers\ItemController;
use App\Http\Controllers\OpeningBalanceController;
use App\Http\Controllers\PartialDayBookReportController;
use App\Http\Controllers\PartyController;
use App\Http\Controllers\PartyWarehouseController;
use App\Http\Controllers\ProductionController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\PurchaseOrderController;
use App\Http\Controllers\RecipeController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\RolePermissionsController;
use App\Http\Controllers\SaleInvoiceController;
use App\Http\Controllers\SaleOrderInvoiceController;
use App\Http\Controllers\SalemanDashboard;
use App\Http\Controllers\SaleOrderController;
use App\Http\Controllers\SaleReportController;
use App\Http\Controllers\SessionController;
use App\Http\Controllers\SurplusBagsReportController;
use App\Http\Controllers\TaxController;
use App\Http\Controllers\TestController;
use App\Http\Controllers\UnitController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\VoucherController;
use App\Http\Controllers\WarehouseController;
use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/


Route::get('/', function () {
    return redirect()->route('login');
});


Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified',])->name('dashboard');

Route::middleware(['auth'])->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    Route::post('/refresh-session', [SessionController::class, 'refreshSession']);
    Route::post('/logout', [SessionController::class, 'logout']);



    Route::get('user/download-sample-file', [UserController::class, 'downloadSampleFile'])->name('user.downloadSampleFile');
    Route::post('user/upload-file', [UserController::class, 'uploadFile'])->name('user.uploadFile');

    Route::middleware(['check.permission'])->group(function () {
        Route::resource('user', UserController::class);
        Route::resource('category', CategoryController::class);
        Route::resource('brand', BrandController::class);
        Route::resource('unit', UnitController::class);
        Route::resource('tax', TaxController::class);    
    });



    //START:: Basic Section

   
    //END:: Basic Section

    // User Permissions
    Route::get('role-permissions/ajax', [RolePermissionsController::class, 'ajax'])->name('role-permissions.ajax');
    Route::resource('role-permissions', RolePermissionsController::class);

    

    Route::get('party-index/{type?}', [PartyController::class, 'index'])->name('party-index');
    Route::resource('party', PartyController::class);

    Route::get('items/get-all', [ItemController::class, 'getAllItems'])->name('items.getAll');
    Route::resource('item', ItemController::class);

    Route::get('recipe/create-version/{id}', [RecipeController::class, 'createVersion'])->name('recipe.createVersion');
    Route::get('/recipes/{id}/detail-with-stock', [RecipeController::class, 'getRecipeDetailWithStock'])->name('getRecipeDetailWithStock');
    Route::resource('recipe', RecipeController::class);

    Route::get('purchase-order/test/create', [PurchaseOrderController::class,'createTest'])->name('purcahse-order.createTest');//********************** */
    Route::get('purchase-order/receiving-bill/print/{id}',[PurchaseOrderController::class,'printReceivingBill'])->name('purchase-order.receiving-bill.print');
    Route::resource('purchase-order', PurchaseOrderController::class);

    Route::resource('sale-order', SaleOrderController::class);

    Route::get('sale-invoice/gate-pass/{id}', [SaleInvoiceController::class, 'printGatePass'])->name('sale-invoice.printGatePass');
    Route::resource('sale-invoice', SaleInvoiceController::class);    // Sale invoices created directly (no sale order)


    // Sale invoices created from a sale order — handled by a dedicated controller
    // so that edit/delete always keep the order balance in sync
    Route::get('sale-order/{saleOrderId}/invoice/create', [SaleOrderInvoiceController::class, 'create'])
        ->name('sale-order-invoice.create');
    Route::resource('sale-order-invoice', SaleOrderInvoiceController::class)
        ->only(['store', 'edit', 'update', 'destroy']);

    Route::get('production/posting/{id}', [ProductionController::class, 'posting'])->name('production.posting');
    Route::get('production/unposting/{id}', [ProductionController::class, 'unposting'])->name('production.unposting');
    Route::resource('production', ProductionController::class);

    Route::resource('expense', ExpenseController::class);

    Route::get('voucher/create-jv', [VoucherController::class, 'createJournalVoucher'])->name('voucher.createJournalVoucher');
    Route::post('voucher/store-jv', [VoucherController::class, 'storeJournalVoucher'])->name('voucher.storeJournalVoucher');
    Route::resource('voucher', VoucherController::class);

    Route::get('chart-of-account/get-by-category/{id}', [ChartOfAccountController::class, 'getByCategory'])->name('chart-of-account.getByCategory');
    Route::resource('chart-of-account', ChartOfAccountController::class);


    Route::get('balance-sheet/request', [BalanceSheetController::class, 'request'])->name('balance-sheet.request');
    Route::get('balance-sheet/show', [BalanceSheetController::class, 'show'])->name('balance-sheet.show');
    
    Route::get('party-warehouse/fetch-list/{party_id}', [PartyWarehouseController::class, 'fetchList'])->name('party-warehouse.fetchList');
    Route::resource('party-warehouse', PartyWarehouseController::class);
    
    Route::get('/admin-dashboard', AdminDashboard::class)->name('admin-dashboard');
    Route::get('/saleman-dashboard', SalemanDashboard::class)->name('saleman-dashboard');


    Route::resource('finished-goods-stock', FinishedGoodsStockController::class);


    Route::resource('contract-settings', ContractSettingController::class);
    Route::resource('contract-voucher', ContractVoucherController::class)
        ->only(['index', 'create', 'store', 'show', 'edit', 'update']);







    // START::Account Section 
        Route::get('account-reports/request', [AccountReportsController::class, 'request'])->name('account-reports.request');
        Route::get('account-reports/voucher-pdf', [AccountReportsController::class, 'voucherPDF'])->name('account-reports.voucherPDF');
        Route::get('account-reports/cashbook-pdf', [AccountReportsController::class, 'cashbookPDF'])->name('account-reports.cashbookPDF');
        Route::get('account-reports/general-ledger-pdf', [AccountReportsController::class, 'generalLedgerPDF'])->name('account-reports.generalLedgerPDF');
        Route::get('account-reports/daybook-pdf', [AccountReportsController::class, 'daybookPDF'])->name('account-reports.daybookPDF');
        Route::get('account-reports/trial-balance-pdf', [AccountReportsController::class, 'trialBalancePDF'])->name('account-reports.trialBalancePDF');
        Route::get('account-reports/customer-balance-pdf', [AccountReportsController::class, 'customerBalancePDF'])->name('account-reports.customerBalancePDF');
        Route::get('account-reports/supplier-balance-pdf', [AccountReportsController::class, 'supplierBalancePDF'])->name('account-reports.supplierBalancePDF');
        Route::get('account-reports/expense-pdf', [AccountReportsController::class, 'expensePDF'])->name('account-reports.expensePDF');
        Route::get('account-reports/customer-ledger-pdf', [AccountReportsController::class, 'customerLedgerPDF'])->name('account-reports.customerLedgerPDF');
        Route::get('account-reports/supplier-ledger-pdf', [AccountReportsController::class, 'supplierLedgerPDF'])->name('account-reports.supplierLedgerPDF');
        Route::get('account-reports/balance-sheet-pdf', [AccountReportsController::class, 'balanceSheetPDF'])->name('account-reports.balanceSheetPDF');
    // END::Account Section

    // START::Inventory Section 
        Route::get('report/raw-material-stock',[ReportController::class,'fetchRawMaterailStock'])->name('report.fetchRawMaterailStock');    
        Route::get('report/finished-goods-stock',[ReportController::class,'fetchFinishedGoodsStock'])->name('report.fetchFinishedGoodsStock');    
        
        Route::get('report/empth-bags-stock',[ReportController::class,'fetchEmptyBagsStock'])->name('report.fetchEmptyBagsStock');    
        
        Route::get('report/production/request', [ReportController::class, 'productionRequest'])->name('report.production.request');
        Route::get('report/production/show', [ReportController::class, 'productionShow'])->name('report.production.show');


        Route::get('report/raw-material-history/request', [ReportController::class, 'rawMaterialHistoryRequest'])->name('report.raw-material-history.request');
        Route::get('report/raw-material-history/show', [ReportController::class, 'rawMaterialHistroyShow'])->name('report.raw-material-history.show');
        
        Route::get('report/material-received-history/request', [ReportController::class, 'materialReceivedHistoryRequest'])->name('report.material-received-history.request');
        Route::get('report/material-received-history/show', [ReportController::class, 'materialReceivedHistoryshow'])->name('report.material-received-history.show');
        
        Route::get('report/raw-material-stock-level/request', [ReportController::class, 'rawMaterialStockLevelRequest'])->name('report.raw-material-stock-level.request');
        Route::post('report/raw-material-stock-level/show', [ReportController::class, 'rawMaterialStockLevelShow'])->name('report.raw-material-stock-level.show');
    // END::Inventory Section
    
    Route::get('average-costing/item-history/request', [AverageCostingController::class, 'itemHistoryRequest'])->name('average-costing.itemHistoryRequest');
    Route::post('average-costing/item-history/show', [AverageCostingController::class, 'itemHistoryShow'])->name('average-costing.itemHistoryShow');
    
    
    Route::get('average-costing/items-list/request', [AverageCostingController::class, 'itemsListRequest'])->name('average-costing.itemsListRequest');
    Route::get('average-costing/items-list/show', [AverageCostingController::class, 'itemsListShow'])->name('average-costing.itemsListShow');


    Route::get('/partial-day-book-report', [PartialDayBookReportController::class,  'index'])->name('partial-day-book-report.index');
    Route::get('/partial-day-book-report/print', [PartialDayBookReportController::class,  'print'])->name('partial-day-book-report.print');
    
    Route::get('/customer-cummulative-sales/request', [SaleReportController::class, 'customerCummulativeSalesRequest'])
    ->name('sale-report.customerCummulativeSalesRequest');
    Route::get('/customer-cummulative-sales/show', [SaleReportController::class, 'customerCummulativeSalesShow'])
    ->name('sale-report.customerCummulativeSalesShow');

    Route::get('/surplus-bags-cummulative-production/request', [SurplusBagsReportController::class, 'cummulativeProductionRequest'])
    ->name('surplus-bags-report.cummulativeProductionRequest');
    Route::get('/surplus-bags-cummulative-production/show', [SurplusBagsReportController::class, 'cummulativeProductionShow'])
    ->name('surplus-bags-report.cummulativeProductionShow');

    Route::get('/surplus-bags-history/request', [SurplusBagsReportController::class, 'historyRequest'])
    ->name('surplus-bags-report.historyRequest');
    Route::get('/surplus-bags-history/show', [SurplusBagsReportController::class, 'historyShow'])
    ->name('surplus-bags-report.historyShow');

});

Route::post('test',[TestController::class, 'test']);







Route::redirect('URI', 'URI', 301);
require __DIR__.'/auth.php';
