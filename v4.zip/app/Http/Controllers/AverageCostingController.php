<?php

namespace App\Http\Controllers;

use App\Models\Item;
use Illuminate\Http\Request;
use App\Models\InvoiceDetail;

class AverageCostingController extends Controller
{
    public function itemHistoryRequest()
    {
        $items = Item::where('type','Raw')->get();
        return view('reports.average_costing_item_history.request', compact('items'));
    }
    public function itemHistoryShow(Request $request)
    {
        
        $item = Item::find($request->item_id);
        
        $transactions = InvoiceDetail::with('item:id,name')
        ->where('item_id',$item->id)
        ->whereIn('type',['receipt','production'])
        ->where('date','<=',$request->date)
        ->orderBy('date','asc')
        ->orderBy('id','asc')
        ->get();

        $stock_weight = 0;
        $stock_value = 0;
        $avg_cost = 0;

        $data = [];
        
        foreach($transactions as $transaction)
        {

            if($transaction->type == 'receipt')
            {
                $stock_value += $transaction->total_price_stock;
                $stock_weight += $transaction->net_weight;

                $avg_cost = $stock_value / $stock_weight;
                
            }
            else if($transaction->type == 'production')
            {           
                $stock_value -= $transaction->net_weight * $avg_cost;
                $stock_weight -= $transaction->net_weight;
 
            }


            $data[] = [
                'date' => $transaction->date,
                'type' => $transaction->type,
                'qty_in' => ($transaction->type == 'receipt') ? $transaction->net_weight : '-',
                'qty_out' => ($transaction->type == 'production') ? $transaction->net_weight : '-',
                'balance' => $stock_weight,
                'balance' => number_format($stock_weight, 4),
                'avg_cost' => ($transaction->type == 'receipt') ? number_format($avg_cost, 4):'-',
                'stock_value' => number_format($stock_weight*$avg_cost, 4),
            ];


           
        }
        
        $date = $request->date;

        return view('reports.average_costing_item_history.show', 
            compact('data','item','date','stock_weight','stock_value','avg_cost')
        );
    }



    public function itemsListRequest()
    {
        return view('reports.average_costing_items_list.request');
    }


    public function itemsListShow(Request $request)
    {
        
        $totalStockValue = 0;
        $items = Item::where('type','Raw')->get();
        $data = [];
        foreach($items as $item)
        {
            $transactions = InvoiceDetail::with('item:id,name')
            ->where('item_id',$item->id)
            ->whereIn('type',['receipt','production'])
            ->where('date','<=',$request->date)
            ->orderBy('date','asc')
            ->orderBy('id','asc')
            ->get();

            $stock_weight = 0;
            $stock_value = 0;
            $avg_cost = 0;
            $stock_alert_qty = 0;
           
            
            if($transactions->sum('net_weight') > 0)
            {
                foreach($transactions as $transaction)
                {
    
                    if($transaction->type == 'receipt')
                    {
                        $stock_value += $transaction->total_price_stock;
                        $stock_weight += $transaction->net_weight;
    
                        if($stock_weight > 0)
                            $avg_cost = $stock_value / $stock_weight;
                       
                        
                    }
                    else if($transaction->type == 'production')
                    {           
                        $stock_value -= $transaction->net_weight * $avg_cost;
                        $stock_weight -= $transaction->net_weight;
                       
         
                    }
    
                }
                $stock_alert_qty = $item->stock_alert_qty != null ? $item->stock_alert_qty  : 0;
                $data[] =[
                    'name' => $item->name,
                    'qty_in' =>  $transactions->where('type','receipt')->sum('net_weight'),
                    'qty_out' =>  $transactions->where('type','production')->sum('net_weight'),
                    'balance' => number_format($stock_weight, 2),
                    'stock_value' => number_format($stock_weight*$avg_cost, 2),
                    'avg_cost' =>  number_format($avg_cost,2),
                    'is_low_stock' => $stock_weight <= $stock_alert_qty,
                ];   
               
                
                $totalStockValue += round(($stock_weight*$avg_cost),4);
            }
            else
            {
                $data[] =[
                    'name' => $item->name,
                    'qty_in' =>  '-',
                    'qty_out' =>  '-',
                    'balance' => '-',
                    'stock_value' => '-',
                    'avg_cost' =>  '-',
                    'is_low_stock' =>  '-',
                ]; 
            }
           
           
        }
       
        return view('reports.average_costing_items_list.show', compact('data','totalStockValue'));
    }

    /*
        //date is required that's why we are using above code 
        public function itemsListShow1(Request $request)
        {
            $items = Item::where('type','Raw')->get();
            $data = [];
            foreach($items as $item)
            {

                $itemData = Item::averageCost($item->id);


                $data[] =[
                    'name' => $item->name,
                    'qty_in' =>  $itemData['qty_in'],
                    'qty_out' =>  $itemData['qty_out'],
                    'balance' =>  $itemData['balance'],
                    'stock_value' =>  $itemData['stock_value'],
                    'avg_cost' =>  $itemData['avg_cost'],
                    
                ];   
            
            
            }
        
            return view('reports.average_costing_items_list.show', compact('data'));
        }
    */


}
